# PXNDA · Registro de ventas de peluches de pandas (Solana + Anchor)

Programa on-chain para un negocio de peluches: patrón (dueño), catálogo, clientes,
ingresos y salidas de mercancía, compras y devoluciones. Incluye un frontend de ejemplo y
dos prompts para reutilizar el proyecto.

```
pxnda-project/
├── programs/pxnda/src/lib.rs   Programa (backend on-chain)
├── Anchor.toml · Cargo.toml
├── scripts/
│   ├── deploy-devnet.sh        Build + deploy en devnet + sincroniza IDL
│   └── sync-idl.sh             Copia target/idl y target/types al frontend
├── app/                        Frontend de ejemplo (React + Vite + wallet adapter)
│   └── src/{App.tsx, lib/pdas.ts, lib/program.ts, idl/}
└── prompts/
    ├── PROMPT_1_adaptar_programa.md          Adaptar el programa a otro caso de uso
    └── PROMPT_2_adaptar_frontend_idl.md      Adaptar el frontend a un nuevo IDL (+ pdas.ts)
```

## Requisitos
Rust, Solana CLI, Anchor CLI (misma versión que `anchor-lang` en `programs/pxnda/Cargo.toml`),
Node 18+ y una wallet de navegador (Phantom, Backpack...).

## Programa desplegado (devnet)
| Dato | Valor |
|---|---|
| Cluster | devnet |
| Program ID | *(pendiente: se imprime al terminar `scripts/deploy-devnet.sh`)* |
| Explorer | `https://explorer.solana.com/address/<PROGRAM_ID>?cluster=devnet` |

```bash
bash scripts/deploy-devnet.sh
```

## Frontend
```bash
cd app
npm install          # fija la versión de @anchor-lang/core que coincida con tu CLI
npm run dev
```
Si `@anchor-lang/core` no se encuentra, instala `@coral-xyz/anchor` y cambia los imports
(la API es la misma).

El IDL incluido es provisional. Tras `anchor build` o `deploy-devnet.sh`, el script
`sync-idl.sh` lo reemplaza por el real.

## Prompts
- **Prompt 1:** adaptar el programa a un nuevo caso de uso.
- **Prompt 2:** adaptar el frontend a un nuevo IDL, regenerando `pdas.ts`.

Flujo: Prompt 1 → `anchor build` → `sync-idl.sh` → Prompt 2 → `npm run build`.

## Estado
Código escrito sin compilar ni desplegar en este entorno: corre `anchor build` y
`npm run build` y corrige lo que marque el compilador.
