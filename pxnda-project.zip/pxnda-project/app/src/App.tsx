import { useCallback, useEffect, useMemo, useState } from "react";
import type { ChangeEvent, InputHTMLAttributes } from "react";
import { useAnchorWallet, useConnection } from "@solana/wallet-adapter-react";
import { WalletMultiButton } from "@solana/wallet-adapter-react-ui";
import { BN } from "@anchor-lang/core";
import { PublicKey, SystemProgram } from "@solana/web3.js";
import idl from "./idl/pxnda.json";
import { getProgram } from "./lib/program";
import {
  findStorePda,
  findPlushPda,
  findCustomerPda,
  findEntryPda,
  findPurchasePda,
  findReturnPda,
} from "./lib/pdas";

const big = (x: { toString(): string }) => BigInt(x.toString());

const In = ({ label, ...p }: { label: string } & InputHTMLAttributes<HTMLInputElement>) => (
  <label>
    {label}
    <input {...p} />
  </label>
);

const STATS: [string, string][] = [
  ["Peluches", "productCount"],
  ["Clientes", "customerCount"],
  ["Ingresos de mercancía", "totalUnitsIn"],
  ["Salidas (ventas)", "totalUnitsOut"],
  ["Devueltas", "totalUnitsReturned"],
  ["Ingresos (lamports)", "totalRevenue"],
  ["Reembolsos (lamports)", "totalRefunded"],
];

export default function App() {
  const { connection } = useConnection();
  const wallet = useAnchorWallet();
  const [store, setStore] = useState<any>(null);
  const [log, setLog] = useState<string[]>([]);
  const [f, setF] = useState({
    storeName: "Pandas Peluche",
    plushName: "Panda clásico",
    price: "100000000",
    plushId: "0",
    quantity: "10",
    customerWallet: "",
    customerName: "",
    customerId: "0",
    purchaseId: "0",
    returnQty: "1",
    restock: true,
  });
  const set = (k: keyof typeof f) => (e: ChangeEvent<HTMLInputElement>) =>
    setF({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });

  // Con el IDL provisional (sin instrucciones) no se puede operar todavía.
  const ready = ((idl as any).instructions?.length ?? 0) > 0;

  // Sin tipos a propósito; ver el comentario en lib/program.ts.
  const program: any = useMemo(
    () => (wallet && ready ? getProgram(connection, wallet) : null),
    [connection, wallet, ready]
  );
  const pid = program?.programId as PublicKey;
  const storePda = useMemo(
    () => (program && wallet ? findStorePda(program.programId, wallet.publicKey)[0] : null),
    [program, wallet]
  );

  const say = (m: string) => setLog((l) => [m, ...l].slice(0, 15));

  const refresh = useCallback(async () => {
    if (!program || !storePda) return setStore(null);
    try {
      setStore(await program.account.store.fetch(storePda));
    } catch {
      setStore(null); // la tienda aún no existe
    }
  }, [program, storePda]);
  useEffect(() => {
    refresh();
  }, [refresh]);

  async function run(label: string, fn: () => Promise<string>) {
    try {
      say(`✔ ${label}: ${await fn()}`);
      await refresh();
    } catch (e: any) {
      say(`✖ ${label}: ${e?.message ?? e}`);
    }
  }

  const need = () => {
    if (!program || !wallet || !storePda) throw new Error("Conecta la wallet (y genera el IDL).");
    if (!store) throw new Error("Primero crea la tienda.");
  };
  const common = { authority: wallet?.publicKey, systemProgram: SystemProgram.programId };

  const actions = {
    initStore: () =>
      run("Crear tienda", async () => {
        if (!program || !storePda) throw new Error("Conecta la wallet (y genera el IDL).");
        return program.methods
          .initializeStore(f.storeName)
          .accountsPartial({ store: storePda, ...common })
          .rpc();
      }),

    addPlush: () =>
      run("Agregar peluche", async () => {
        need();
        const [plush] = findPlushPda(pid, storePda!, store.productCount);
        return program.methods
          .addPlush(f.plushName, new BN(f.price))
          .accountsPartial({ store: storePda, plush, ...common })
          .rpc();
      }),

    stockEntry: () =>
      run("Ingreso de mercancía", async () => {
        need();
        const [plush] = findPlushPda(pid, storePda!, Number(f.plushId));
        const [entry] = findEntryPda(pid, storePda!, big(store.entryCount));
        return program.methods
          .registerStockEntry(Number(f.quantity))
          .accountsPartial({ store: storePda, plush, entry, ...common })
          .rpc();
      }),

    addCustomer: () =>
      run("Registrar cliente", async () => {
        need();
        const [customer] = findCustomerPda(pid, storePda!, store.customerCount);
        return program.methods
          .registerCustomer(new PublicKey(f.customerWallet), f.customerName)
          .accountsPartial({ store: storePda, customer, ...common })
          .rpc();
      }),

    purchase: () =>
      run("Registrar compra", async () => {
        need();
        const [plush] = findPlushPda(pid, storePda!, Number(f.plushId));
        const [customer] = findCustomerPda(pid, storePda!, Number(f.customerId));
        const [purchase] = findPurchasePda(pid, storePda!, big(store.purchaseCount));
        return program.methods
          .registerPurchase(Number(f.quantity))
          .accountsPartial({ store: storePda, plush, customer, purchase, ...common })
          .rpc();
      }),

    doReturn: () =>
      run("Registrar devolución", async () => {
        need();
        const [purchase] = findPurchasePda(pid, storePda!, Number(f.purchaseId));
        const p = await program.account.purchase.fetch(purchase); // trae customer y plush de la compra
        const [returnRecord] = findReturnPda(pid, storePda!, big(store.returnCount));
        return program.methods
          .registerReturn(Number(f.returnQty), f.restock)
          .accountsPartial({
            store: storePda,
            plush: p.plush,
            customer: p.customer,
            purchase,
            returnRecord,
            ...common,
          })
          .rpc();
      }),
  };

  return (
    <main>
      <header>
        <h1>🐼 PXNDA</h1>
        <WalletMultiButton />
      </header>

      {!ready && (
        <div className="warn">
          El IDL es provisional. Ejecuta <code>anchor build</code> y luego <code>npm run sync-idl</code>.
        </div>
      )}

      <section>
        <h2>Tienda {store ? `· ${store.name}` : ""}</h2>
        {store ? (
          <div className="stats">
            {STATS.map(([label, key]) => (
              <div className="stat" key={key}>
                {label}
                <b>{store[key].toString()}</b>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid">
            <In label="Nombre de la tienda" value={f.storeName} onChange={set("storeName")} />
            <button className="act" onClick={actions.initStore}>Crear tienda</button>
          </div>
        )}
      </section>

      <section>
        <h2>Catálogo e inventario</h2>
        <div className="grid">
          <In label="Nombre del peluche" value={f.plushName} onChange={set("plushName")} />
          <In label="Precio (lamports)" value={f.price} onChange={set("price")} />
          <button className="act" onClick={actions.addPlush}>Agregar peluche</button>
        </div>
        <div className="grid" style={{ marginTop: 12 }}>
          <In label="Id del peluche" value={f.plushId} onChange={set("plushId")} />
          <In label="Cantidad que ingresa" value={f.quantity} onChange={set("quantity")} />
          <button className="act" onClick={actions.stockEntry}>Registrar ingreso</button>
        </div>
      </section>

      <section>
        <h2>Clientes</h2>
        <div className="grid">
          <In label="Wallet del cliente" value={f.customerWallet} onChange={set("customerWallet")} />
          <In label="Nombre" value={f.customerName} onChange={set("customerName")} />
          <button className="act" onClick={actions.addCustomer}>Registrar cliente</button>
        </div>
      </section>

      <section>
        <h2>Compras</h2>
        <div className="grid">
          <In label="Id del cliente" value={f.customerId} onChange={set("customerId")} />
          <In label="Id del peluche" value={f.plushId} onChange={set("plushId")} />
          <In label="Cantidad" value={f.quantity} onChange={set("quantity")} />
          <button className="act" onClick={actions.purchase}>Registrar compra</button>
        </div>
      </section>

      <section>
        <h2>Devoluciones</h2>
        <div className="grid">
          <In label="Id de la compra" value={f.purchaseId} onChange={set("purchaseId")} />
          <In label="Cantidad devuelta" value={f.returnQty} onChange={set("returnQty")} />
          <In label="Regresa al inventario" type="checkbox" checked={f.restock} onChange={set("restock")} />
          <button className="act" onClick={actions.doReturn}>Registrar devolución</button>
        </div>
      </section>

      <section>
        <h2>Actividad</h2>
        <pre>{log.length ? log.join("\n") : "Sin movimientos todavía."}</pre>
      </section>
    </main>
  );
}
