// PDAs de PXNDA. Cada función replica EXACTAMENTE las seeds de programs/pxnda/src/lib.rs.
//
//   Tienda     ["pxnda-store",    patrón]
//   Peluche    ["pxnda-plush",    tienda, id u32 LE]
//   Cliente    ["pxnda-customer", tienda, id u32 LE]
//   Ingreso    ["pxnda-entry",    tienda, id u64 LE]
//   Compra     ["pxnda-purchase", tienda, id u64 LE]
//   Devolución ["pxnda-return",   tienda, id u64 LE]
import { PublicKey } from "@solana/web3.js";

export type Id = number | bigint;

const utf8 = (s: string) => new TextEncoder().encode(s);

function u32le(n: Id): Uint8Array {
  const b = new Uint8Array(4);
  new DataView(b.buffer).setUint32(0, Number(n), true);
  return b;
}

function u64le(n: Id): Uint8Array {
  const b = new Uint8Array(8);
  new DataView(b.buffer).setBigUint64(0, BigInt(n), true);
  return b;
}

export const SEEDS = {
  store: "pxnda-store",
  plush: "pxnda-plush",
  customer: "pxnda-customer",
  entry: "pxnda-entry",
  purchase: "pxnda-purchase",
  ret: "pxnda-return",
} as const;

export const findStorePda = (programId: PublicKey, authority: PublicKey) =>
  PublicKey.findProgramAddressSync([utf8(SEEDS.store), authority.toBytes()], programId);

export const findPlushPda = (programId: PublicKey, store: PublicKey, id: Id) =>
  PublicKey.findProgramAddressSync([utf8(SEEDS.plush), store.toBytes(), u32le(id)], programId);

export const findCustomerPda = (programId: PublicKey, store: PublicKey, id: Id) =>
  PublicKey.findProgramAddressSync([utf8(SEEDS.customer), store.toBytes(), u32le(id)], programId);

export const findEntryPda = (programId: PublicKey, store: PublicKey, id: Id) =>
  PublicKey.findProgramAddressSync([utf8(SEEDS.entry), store.toBytes(), u64le(id)], programId);

export const findPurchasePda = (programId: PublicKey, store: PublicKey, id: Id) =>
  PublicKey.findProgramAddressSync([utf8(SEEDS.purchase), store.toBytes(), u64le(id)], programId);

export const findReturnPda = (programId: PublicKey, store: PublicKey, id: Id) =>
  PublicKey.findProgramAddressSync([utf8(SEEDS.ret), store.toBytes(), u64le(id)], programId);
