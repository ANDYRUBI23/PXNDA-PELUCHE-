import { AnchorProvider, Program } from "@anchor-lang/core";
import type { AnchorWallet } from "@solana/wallet-adapter-react";
import type { Connection } from "@solana/web3.js";
import idl from "../idl/pxnda.json";

// Devuelve el programa ligado a la wallet conectada.
// Para tipado fuerte, importa `Pxnda` de ../idl/pxnda.ts (lo genera `anchor build`)
// y usa `new Program<Pxnda>(...)`. Aquí va sin tipos para que compile con el IDL provisional.
export function getProgram(connection: Connection, wallet: AnchorWallet) {
  const provider = new AnchorProvider(connection, wallet, { commitment: "confirmed" });
  return new Program(idl as any, provider);
}
