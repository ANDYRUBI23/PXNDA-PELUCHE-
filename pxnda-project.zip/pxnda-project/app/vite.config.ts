import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { nodePolyfills } from "vite-plugin-node-polyfills";

// web3.js / anchor necesitan Buffer en el navegador.
export default defineConfig({
  plugins: [react(), nodePolyfills({ globals: { Buffer: true } })],
});
