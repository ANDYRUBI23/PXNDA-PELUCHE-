// PXNDA: registro de ventas de un negocio de peluches de pandas.
//
// Patrón de direcciones (PDAs), todas colgando de la tienda:
//   Tienda    -> ["pxnda-store",    patrón]
//   Peluche   -> ["pxnda-plush",    tienda, id (u32 LE)]
//   Cliente   -> ["pxnda-customer", tienda, id (u32 LE)]
//   Ingreso   -> ["pxnda-entry",    tienda, id (u64 LE)]   mercancía que entra
//   Compra    -> ["pxnda-purchase", tienda, id (u64 LE)]   mercancía que sale
//   Devolución-> ["pxnda-return",   tienda, id (u64 LE)]
//
// El "patrón" es el dueño del negocio: la única wallet que puede registrar
// movimientos. Los ids salen de contadores de la tienda, así cada registro
// tiene una dirección predecible y no se puede duplicar.
use anchor_lang::prelude::*;

// Placeholder: ejecuta `anchor keys sync` para generar y fijar tu ID real.
declare_id!("11111111111111111111111111111111");

pub const MAX_NAME: usize = 32;

fn add_u32(a: u32, b: u32) -> Result<u32> {
    a.checked_add(b).ok_or_else(|| error!(PxndaError::Overflow))
}

fn add_u64(a: u64, b: u64) -> Result<u64> {
    a.checked_add(b).ok_or_else(|| error!(PxndaError::Overflow))
}

#[program]
pub mod pxnda {
    use super::*;

    /// El patrón crea su tienda.
    pub fn initialize_store(ctx: Context<InitializeStore>, name: String) -> Result<()> {
        require!(name.len() <= MAX_NAME, PxndaError::NameTooLong);

        let store = &mut ctx.accounts.store;
        store.authority = ctx.accounts.authority.key();
        store.name = name;
        store.product_count = 0;
        store.customer_count = 0;
        store.entry_count = 0;
        store.purchase_count = 0;
        store.return_count = 0;
        store.total_units_in = 0;
        store.total_units_out = 0;
        store.total_units_returned = 0;
        store.total_revenue = 0;
        store.total_refunded = 0;
        store.bump = ctx.bumps.store;
        Ok(())
    }

    /// Da de alta un peluche en el catálogo (empieza con stock 0).
    /// El precio va en lamports.
    pub fn add_plush(ctx: Context<AddPlush>, name: String, price: u64) -> Result<()> {
        require!(name.len() <= MAX_NAME, PxndaError::NameTooLong);
        require!(price > 0, PxndaError::InvalidPrice);

        let store = &mut ctx.accounts.store;
        let plush = &mut ctx.accounts.plush;
        plush.store = store.key();
        plush.id = store.product_count;
        plush.name = name;
        plush.price = price;
        plush.stock = 0;
        plush.units_in = 0;
        plush.units_out = 0;
        plush.units_returned = 0;
        plush.active = true;
        plush.bump = ctx.bumps.plush;

        store.product_count = add_u32(store.product_count, 1)?;
        Ok(())
    }

    /// Registra mercancía que INGRESA al inventario.
    pub fn register_stock_entry(ctx: Context<RegisterStockEntry>, quantity: u32) -> Result<()> {
        require!(quantity > 0, PxndaError::InvalidQuantity);

        let store = &mut ctx.accounts.store;
        let plush = &mut ctx.accounts.plush;
        let entry = &mut ctx.accounts.entry;

        plush.stock = add_u32(plush.stock, quantity)?;
        plush.units_in = add_u64(plush.units_in, quantity as u64)?;
        store.total_units_in = add_u64(store.total_units_in, quantity as u64)?;

        entry.store = store.key();
        entry.entry_id = store.entry_count;
        entry.plush = plush.key();
        entry.plush_id = plush.id;
        entry.quantity = quantity;
        entry.timestamp = Clock::get()?.unix_timestamp;
        entry.bump = ctx.bumps.entry;

        store.entry_count = add_u64(store.entry_count, 1)?;

        emit!(StockEntered {
            store: store.key(),
            plush_id: plush.id,
            quantity,
        });
        Ok(())
    }

    /// Registra un cliente nuevo.
    pub fn register_customer(
        ctx: Context<RegisterCustomer>,
        wallet: Pubkey,
        name: String,
    ) -> Result<()> {
        require!(name.len() <= MAX_NAME, PxndaError::NameTooLong);

        let store = &mut ctx.accounts.store;
        let customer = &mut ctx.accounts.customer;
        customer.store = store.key();
        customer.id = store.customer_count;
        customer.wallet = wallet;
        customer.name = name;
        customer.purchases_count = 0;
        customer.total_spent = 0;
        customer.total_refunded = 0;
        customer.bump = ctx.bumps.customer;

        store.customer_count = add_u32(store.customer_count, 1)?;
        Ok(())
    }

    /// Registra una compra: mercancía que SALE del inventario.
    pub fn register_purchase(ctx: Context<RegisterPurchase>, quantity: u32) -> Result<()> {
        require!(quantity > 0, PxndaError::InvalidQuantity);

        let store = &mut ctx.accounts.store;
        let plush = &mut ctx.accounts.plush;
        let customer = &mut ctx.accounts.customer;
        let purchase = &mut ctx.accounts.purchase;

        require!(plush.active, PxndaError::PlushInactive);
        require!(plush.stock >= quantity, PxndaError::InsufficientStock);

        let total = plush
            .price
            .checked_mul(quantity as u64)
            .ok_or(PxndaError::Overflow)?;

        plush.stock -= quantity;
        plush.units_out = add_u64(plush.units_out, quantity as u64)?;

        customer.purchases_count = add_u32(customer.purchases_count, 1)?;
        customer.total_spent = add_u64(customer.total_spent, total)?;

        store.total_units_out = add_u64(store.total_units_out, quantity as u64)?;
        store.total_revenue = add_u64(store.total_revenue, total)?;

        purchase.store = store.key();
        purchase.purchase_id = store.purchase_count;
        purchase.customer = customer.key();
        purchase.plush = plush.key();
        purchase.plush_id = plush.id;
        purchase.quantity = quantity;
        purchase.returned_qty = 0;
        purchase.unit_price = plush.price;
        purchase.total = total;
        purchase.timestamp = Clock::get()?.unix_timestamp;
        purchase.bump = ctx.bumps.purchase;

        store.purchase_count = add_u64(store.purchase_count, 1)?;

        emit!(PurchaseRegistered {
            store: store.key(),
            purchase_id: purchase.purchase_id,
            customer_id: customer.id,
            plush_id: plush.id,
            quantity,
            total,
        });
        Ok(())
    }

    /// Registra una devolución (total o parcial) de una compra.
    /// `restock = true` regresa las piezas al inventario (buen estado).
    pub fn register_return(
        ctx: Context<RegisterReturn>,
        quantity: u32,
        restock: bool,
    ) -> Result<()> {
        require!(quantity > 0, PxndaError::InvalidQuantity);

        let store = &mut ctx.accounts.store;
        let plush = &mut ctx.accounts.plush;
        let customer = &mut ctx.accounts.customer;
        let purchase = &mut ctx.accounts.purchase;
        let record = &mut ctx.accounts.return_record;

        let returnable = purchase
            .quantity
            .checked_sub(purchase.returned_qty)
            .ok_or(PxndaError::Overflow)?;
        require!(quantity <= returnable, PxndaError::ReturnExceedsPurchase);

        let refund = purchase
            .unit_price
            .checked_mul(quantity as u64)
            .ok_or(PxndaError::Overflow)?;

        purchase.returned_qty = add_u32(purchase.returned_qty, quantity)?;

        plush.units_returned = add_u64(plush.units_returned, quantity as u64)?;
        if restock {
            plush.stock = add_u32(plush.stock, quantity)?;
        }

        customer.total_refunded = add_u64(customer.total_refunded, refund)?;

        store.total_units_returned = add_u64(store.total_units_returned, quantity as u64)?;
        store.total_refunded = add_u64(store.total_refunded, refund)?;

        record.store = store.key();
        record.return_id = store.return_count;
        record.purchase = purchase.key();
        record.quantity = quantity;
        record.refund = refund;
        record.restocked = restock;
        record.timestamp = Clock::get()?.unix_timestamp;
        record.bump = ctx.bumps.return_record;

        store.return_count = add_u64(store.return_count, 1)?;

        emit!(ReturnRegistered {
            store: store.key(),
            return_id: record.return_id,
            purchase_id: purchase.purchase_id,
            quantity,
            refund,
            restocked: restock,
        });
        Ok(())
    }
}

// ---------------------------------------------------------------------------
// Contextos de cuentas
// ---------------------------------------------------------------------------

#[derive(Accounts)]
pub struct InitializeStore<'info> {
    #[account(
        init,
        payer = authority,
        space = 8 + Store::INIT_SPACE,
        seeds = [b"pxnda-store", authority.key().as_ref()],
        bump
    )]
    pub store: Account<'info, Store>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct AddPlush<'info> {
    #[account(
        mut,
        seeds = [b"pxnda-store", authority.key().as_ref()],
        bump = store.bump,
        has_one = authority @ PxndaError::Unauthorized
    )]
    pub store: Account<'info, Store>,
    #[account(
        init,
        payer = authority,
        space = 8 + Plush::INIT_SPACE,
        seeds = [b"pxnda-plush", store.key().as_ref(), &store.product_count.to_le_bytes()],
        bump
    )]
    pub plush: Account<'info, Plush>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct RegisterStockEntry<'info> {
    #[account(
        mut,
        seeds = [b"pxnda-store", authority.key().as_ref()],
        bump = store.bump,
        has_one = authority @ PxndaError::Unauthorized
    )]
    pub store: Account<'info, Store>,
    #[account(mut, has_one = store @ PxndaError::WrongStore)]
    pub plush: Account<'info, Plush>,
    #[account(
        init,
        payer = authority,
        space = 8 + StockEntry::INIT_SPACE,
        seeds = [b"pxnda-entry", store.key().as_ref(), &store.entry_count.to_le_bytes()],
        bump
    )]
    pub entry: Account<'info, StockEntry>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct RegisterCustomer<'info> {
    #[account(
        mut,
        seeds = [b"pxnda-store", authority.key().as_ref()],
        bump = store.bump,
        has_one = authority @ PxndaError::Unauthorized
    )]
    pub store: Account<'info, Store>,
    #[account(
        init,
        payer = authority,
        space = 8 + Customer::INIT_SPACE,
        seeds = [b"pxnda-customer", store.key().as_ref(), &store.customer_count.to_le_bytes()],
        bump
    )]
    pub customer: Account<'info, Customer>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct RegisterPurchase<'info> {
    #[account(
        mut,
        seeds = [b"pxnda-store", authority.key().as_ref()],
        bump = store.bump,
        has_one = authority @ PxndaError::Unauthorized
    )]
    pub store: Account<'info, Store>,
    #[account(mut, has_one = store @ PxndaError::WrongStore)]
    pub plush: Account<'info, Plush>,
    #[account(mut, has_one = store @ PxndaError::WrongStore)]
    pub customer: Account<'info, Customer>,
    #[account(
        init,
        payer = authority,
        space = 8 + Purchase::INIT_SPACE,
        seeds = [b"pxnda-purchase", store.key().as_ref(), &store.purchase_count.to_le_bytes()],
        bump
    )]
    pub purchase: Account<'info, Purchase>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct RegisterReturn<'info> {
    #[account(
        mut,
        seeds = [b"pxnda-store", authority.key().as_ref()],
        bump = store.bump,
        has_one = authority @ PxndaError::Unauthorized
    )]
    pub store: Account<'info, Store>,
    #[account(mut, has_one = store @ PxndaError::WrongStore)]
    pub plush: Account<'info, Plush>,
    #[account(mut, has_one = store @ PxndaError::WrongStore)]
    pub customer: Account<'info, Customer>,
    #[account(
        mut,
        has_one = store @ PxndaError::WrongStore,
        has_one = customer @ PxndaError::PurchaseMismatch,
        has_one = plush @ PxndaError::PurchaseMismatch
    )]
    pub purchase: Account<'info, Purchase>,
    #[account(
        init,
        payer = authority,
        space = 8 + ReturnRecord::INIT_SPACE,
        seeds = [b"pxnda-return", store.key().as_ref(), &store.return_count.to_le_bytes()],
        bump
    )]
    pub return_record: Account<'info, ReturnRecord>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

// ---------------------------------------------------------------------------
// Cuentas de datos
// ---------------------------------------------------------------------------

/// La tienda. `authority` es el patrón (dueño).
#[account]
#[derive(InitSpace)]
pub struct Store {
    pub authority: Pubkey,
    #[max_len(32)]
    pub name: String,
    pub product_count: u32,
    pub customer_count: u32,
    pub entry_count: u64,
    pub purchase_count: u64,
    pub return_count: u64,
    pub total_units_in: u64,       // mercancía que ha ingresado
    pub total_units_out: u64,      // mercancía que ha salido (ventas brutas)
    pub total_units_returned: u64, // piezas devueltas
    pub total_revenue: u64,        // ingresos brutos en lamports
    pub total_refunded: u64,       // reembolsos en lamports
    pub bump: u8,
}

#[account]
#[derive(InitSpace)]
pub struct Plush {
    pub store: Pubkey,
    pub id: u32,
    #[max_len(32)]
    pub name: String,
    pub price: u64,
    pub stock: u32,
    pub units_in: u64,
    pub units_out: u64,
    pub units_returned: u64,
    pub active: bool,
    pub bump: u8,
}

#[account]
#[derive(InitSpace)]
pub struct Customer {
    pub store: Pubkey,
    pub id: u32,
    pub wallet: Pubkey,
    #[max_len(32)]
    pub name: String,
    pub purchases_count: u32,
    pub total_spent: u64,
    pub total_refunded: u64,
    pub bump: u8,
}

#[account]
#[derive(InitSpace)]
pub struct StockEntry {
    pub store: Pubkey,
    pub entry_id: u64,
    pub plush: Pubkey,
    pub plush_id: u32,
    pub quantity: u32,
    pub timestamp: i64,
    pub bump: u8,
}

#[account]
#[derive(InitSpace)]
pub struct Purchase {
    pub store: Pubkey,
    pub purchase_id: u64,
    pub customer: Pubkey,
    pub plush: Pubkey,
    pub plush_id: u32,
    pub quantity: u32,
    pub returned_qty: u32,
    pub unit_price: u64,
    pub total: u64,
    pub timestamp: i64,
    pub bump: u8,
}

#[account]
#[derive(InitSpace)]
pub struct ReturnRecord {
    pub store: Pubkey,
    pub return_id: u64,
    pub purchase: Pubkey,
    pub quantity: u32,
    pub refund: u64,
    pub restocked: bool,
    pub timestamp: i64,
    pub bump: u8,
}

// ---------------------------------------------------------------------------
// Eventos y errores
// ---------------------------------------------------------------------------

#[event]
pub struct StockEntered {
    pub store: Pubkey,
    pub plush_id: u32,
    pub quantity: u32,
}

#[event]
pub struct PurchaseRegistered {
    pub store: Pubkey,
    pub purchase_id: u64,
    pub customer_id: u32,
    pub plush_id: u32,
    pub quantity: u32,
    pub total: u64,
}

#[event]
pub struct ReturnRegistered {
    pub store: Pubkey,
    pub return_id: u64,
    pub purchase_id: u64,
    pub quantity: u32,
    pub refund: u64,
    pub restocked: bool,
}

#[error_code]
pub enum PxndaError {
    #[msg("Solo el patrón (dueño de la tienda) puede hacer esto")]
    Unauthorized,
    #[msg("La cuenta no pertenece a esta tienda")]
    WrongStore,
    #[msg("La compra no corresponde a ese cliente o peluche")]
    PurchaseMismatch,
    #[msg("El nombre es demasiado largo (máximo 32 bytes)")]
    NameTooLong,
    #[msg("El precio debe ser mayor que cero")]
    InvalidPrice,
    #[msg("La cantidad debe ser mayor que cero")]
    InvalidQuantity,
    #[msg("Inventario insuficiente")]
    InsufficientStock,
    #[msg("El peluche está desactivado")]
    PlushInactive,
    #[msg("Se intenta devolver más piezas de las compradas")]
    ReturnExceedsPurchase,
    #[msg("Desbordamiento aritmético")]
    Overflow,
}
