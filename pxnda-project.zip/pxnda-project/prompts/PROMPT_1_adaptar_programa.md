# PROMPT 1 — Adaptar el programa a un nuevo caso de uso

Copia todo lo que está bajo la línea, rellena los campos `[ENTRE CORCHETES]` y pégalo
en tu asistente junto con el contenido de `programs/pxnda/src/lib.rs`.

---

Eres un ingeniero senior de Solana con Anchor. Adapta el programa adjunto (PXNDA, un
registro de ventas de peluches) a un caso de uso nuevo, conservando su arquitectura.

## Caso de uso nuevo
- Negocio / dominio: [p. ej. renta de bicicletas, clínica veterinaria, tienda de café]
- Nombre del programa (snake_case): [nombre]
- Entidades (equivalentes a Peluche / Cliente): [lista]
- Movimientos de entrada y de salida de inventario o saldo: [lista]
- Operaciones que debe soportar: [altas, ventas/servicios, devoluciones/cancelaciones, ...]
- Roles: el "patrón" es el dueño y única `authority`. Otros roles: [ninguno / lista]
- Versión de Anchor: [la de `anchor --version`]

## Reglas que debes respetar
1. Patrón de PDAs: una cuenta raíz (`Store`) cuyas seeds llevan el prefijo del programa y la
   wallet del patrón; el resto de cuentas cuelga de ella con seeds
   `[prefijo, raíz, id_contador_LE]`. Los ids salen de contadores guardados en la raíz.
2. Toda instrucción que modifica datos exige `has_one = authority` con error propio
   (`@ Error::Unauthorized`) y relaciones `has_one` entre cuentas hijas y la raíz.
3. Aritmética solo con `checked_*`; errores personalizados con `#[msg]` en español.
4. `#[derive(InitSpace)]` con `#[max_len]` en cada `String`; `space = 8 + X::INIT_SPACE`.
5. Guarda `bump` en cada PDA y úsalo en validaciones (`bump = x.bump`).
6. Evita palabras reservadas de Rust como nombres de campos o cuentas.
7. Emite un `#[event]` por cada operación importante.
8. El programa solo registra, salvo que el caso de uso pida mover fondos; en ese caso
   dilo explícitamente y valida cada cuenta de transferencia.

## Entrega
1. `lib.rs` completo y compilable.
2. Tabla "antes → después" de cuentas, instrucciones y errores.
3. Tabla de PDAs: cuenta, seeds en orden y tipo de cada seed (string / Pubkey / u32 LE / u64 LE).
4. Lista de cambios que alteran el IDL (nombres de instrucciones, argumentos, cuentas), porque
   el frontend dependerá de ellos (ver PROMPT 2).
5. Comandos para verificar: `anchor build`, `bash scripts/sync-idl.sh`.

## Antes de responder, revisa
- [ ] Ninguna seed usa datos que cambien después de crear la cuenta.
- [ ] Ningún contador puede desbordarse sin error.
- [ ] No hay instrucción que modifique datos sin validar `authority`.
- [ ] Las seeds quedaron documentadas en la tabla de PDAs.
