# PROMPT 2 — Adaptar el frontend a un nuevo IDL (incluye pdas.ts)

Pégalo en tu asistente junto con: el nuevo IDL (`target/idl/<programa>.json`), el nuevo
`lib.rs`, y los archivos `app/src/lib/pdas.ts`, `app/src/lib/program.ts` y `app/src/App.tsx`.

---

Eres un ingeniero senior de Solana/TypeScript. Adapta el frontend de ejemplo (React + Vite +
wallet adapter + cliente TypeScript de Anchor) al IDL nuevo que te adjunto.

## Datos
- Nombre del programa (como aparece en el IDL): [nombre]
- Cluster: [devnet / localnet / mainnet]
- Vocabulario de la interfaz (en español): [términos del nuevo negocio]

## Tareas
1. **IDL**: reemplaza `app/src/idl/<programa>.json` (y `.ts` si existe) y actualiza los imports.
2. **`app/src/lib/pdas.ts`**: reescríbelo a partir de las `seeds` del IDL / del programa.
   - Una función `find<Cuenta>Pda(programId, ...)` por cada PDA, y un objeto `SEEDS` con los prefijos.
   - Codificación exacta: string → UTF-8; Pubkey → `toBytes()`; `u32` → 4 bytes little-endian;
     `u64` → 8 bytes little-endian; `u8` → 1 byte.
   - Cada función devuelve `[PublicKey, bump]` (`findProgramAddressSync`).
   - Deja en el encabezado un comentario con la tabla de seeds, igual que el archivo actual.
3. **`app/src/lib/program.ts`**: tipa el `Program` con el tipo generado por `anchor build`.
4. **`app/src/App.tsx`**: crea un formulario por instrucción del IDL.
   - Nombres de métodos en camelCase (`register_sale` → `registerSale`).
   - Pasa TODAS las cuentas con `accountsPartial`, calculadas con `pdas.ts`, porque las seeds que
     dependen de contadores no se resuelven solas.
   - Argumentos `u64` → `BN`; `u32`/`u8` → `number`; `Pubkey` → `PublicKey`; `bool` → boolean.
   - Muestra los datos de la cuenta raíz y maneja el caso "aún no existe".
   - Los ids de contador que vienen como `BN` se convierten con `BigInt(x.toString())`.
5. Elimina todo lo específico del caso de uso anterior.

## Entrega
1. Archivos completos modificados (`pdas.ts`, `program.ts`, `App.tsx`).
2. Tabla: instrucción del IDL → formulario → cuentas (con su función de `pdas.ts`).
3. Resultado esperado de `npm run build` (sin errores de tipos).

## Prueba manual (devnet)
- [ ] Conectar wallet, crear la cuenta raíz y ver sus contadores.
- [ ] Ejecutar cada instrucción una vez y comprobar que el contador correspondiente subió.
- [ ] Una PDA calculada en `pdas.ts` coincide con la que muestra el explorador / `anchor test`.
