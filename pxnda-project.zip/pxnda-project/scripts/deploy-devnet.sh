#!/usr/bin/env bash
# Despliega PXNDA en devnet. Ejecutar desde la raíz del proyecto.
set -euo pipefail
solana config set --url devnet
solana airdrop 2 || echo "Airdrop falló: usa https://faucet.solana.com"
anchor keys sync          # fija el declare_id! y Anchor.toml con tu keypair
anchor build
anchor deploy --provider.cluster devnet
bash scripts/sync-idl.sh
ID="$(solana address -k target/deploy/pxnda-keypair.json)"
echo "Program ID: $ID"
echo "Explorer:   https://explorer.solana.com/address/$ID?cluster=devnet"
