#!/usr/bin/env bash
# Copia el IDL (y los tipos TS) generados por `anchor build` al frontend.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/app/src/idl"
cp "$ROOT/target/idl/pxnda.json" "$ROOT/app/src/idl/pxnda.json"
if [ -f "$ROOT/target/types/pxnda.ts" ]; then
  cp "$ROOT/target/types/pxnda.ts" "$ROOT/app/src/idl/pxnda.ts"
fi
echo "IDL sincronizado en app/src/idl/"
